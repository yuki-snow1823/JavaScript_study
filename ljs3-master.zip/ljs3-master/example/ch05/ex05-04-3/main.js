console.log(NaN === NaN); // false
console.log(NaN == NaN); // false
console.log(isNaN(NaN)); // true
console.log(isNaN(3)); // false
console.log(isNaN(3.6)); // false
console.log(isNaN("abc")); // true
