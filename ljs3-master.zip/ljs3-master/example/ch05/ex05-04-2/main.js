console.log(3 > 5);  // false  （3は5より大きくはない）
console.log(3 >= 5);  // false  （3は5以上ではない）
console.log(3 < 5);  // true  （3は5より小さい）
console.log(3 <= 5);  // true  （3は5以下である）

console.log(5 > 5);  // false
console.log(5 >= 5);  // true
console.log(5 < 5);  // false
console.log(5 <= 5);  // true
