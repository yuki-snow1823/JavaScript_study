let a = 5, b = 10;
[a, b] = [b, a];
console.log(a); // 10
console.log(b); // 5
