console.log(10%3);  // 1
console.log(-10%3);  // -1
console.log(-10%4);  // -2
console.log(10%-3);  // 1
console.log(10%-4);  // 2
console.log(10%3.6);  // 2.8
console.log(10%2.5);  // 0
