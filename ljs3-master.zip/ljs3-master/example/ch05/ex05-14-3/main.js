const arr = [1, 2, 3];
let [x, y] = arr;
console.log(x); // 1
console.log(y); // 2
