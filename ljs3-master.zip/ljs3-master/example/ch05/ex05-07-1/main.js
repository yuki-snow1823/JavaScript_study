const doIt = false;
const result = doIt ? "Did it!" : "Didn't do it.";
console.log(result); // Didn't do it.
