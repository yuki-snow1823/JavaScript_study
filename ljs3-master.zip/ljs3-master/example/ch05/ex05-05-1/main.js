console.log(3 + 5 + "8"); // 88
console.log("3" + 5 + 8); // 358
