function getGreeting() {
  return "Hello world!";
}

console.log(getGreeting()); // Hello world!
console.log(getGreeting); // function getGreeting()
