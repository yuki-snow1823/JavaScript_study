function sayHello() {  // 関数の本体は「{」で始まる
   console.log("Hello world!");
   console.log("こんにちは、世界！");
   console.log("¡Hola mundo!");
   console.log("Hallo wereld!");
   console.log("Привет мир!");
}   // 「}」で終わる

sayHello();   // 関数が呼び出され、コンソールに「Hello, World!」がいろいろな言葉で表示される
