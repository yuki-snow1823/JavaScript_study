function avg(a, b) {
 return (a + b)/2;
}
// #@@range_begin(list1)
console.log(avg(5, 10));  // 7.5
// #@@range_end(list1)
