function f(x) {
  return `f内のxの値: ${x}`;
}
console.log(f()); // "f内のxの値: undefined"
