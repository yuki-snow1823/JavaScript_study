let whoops = 3;
whoops();
