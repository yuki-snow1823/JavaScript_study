function getGreeting() {
  return "Hello world!"; // 値（戻り値）を返す
}

const message = getGreeting(); // 関数が呼び出され、戻り値が代入される
console.log(message);   
