function avg(a, b) {
 return (a + b)/2;
}

const a = 5, b = 10;
console.log(avg(a, b)); // 7.5
