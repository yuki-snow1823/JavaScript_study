const arr = Array(10).map(function(x) { return 5 });
console.log(arr); // [ , , , , , , , , ,  ]
