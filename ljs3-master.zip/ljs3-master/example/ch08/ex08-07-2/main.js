const お供 = ["キジ", "犬", "サル"];
const html = '<ul><li>' + お供.join('</li><li>') + '</li></ul>';
console.log(html); // <ul><li>キジ</li><li>犬</li><li>サル</li></ul>
