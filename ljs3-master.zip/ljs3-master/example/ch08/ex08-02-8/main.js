let arr = [5, 3, 2, 4, 1];
let arr2 = arr.sort();
console.log(arr); // [ 1, 2, 3, 4, 5 ]
console.log(arr2); // [ 1, 2, 3, 4, 5 ]
arr2.reverse();
console.log(arr); // [ 5, 4, 3, 2, 1 ]
console.log(arr2); // [ 5, 4, 3, 2, 1 ]
