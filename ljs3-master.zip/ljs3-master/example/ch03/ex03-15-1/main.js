const now = new Date();
console.log(now); // 2016-08-08T07:52:50.564Z  （処理系により異なる）
