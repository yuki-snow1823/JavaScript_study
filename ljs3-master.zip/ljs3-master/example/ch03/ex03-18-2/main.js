const d = new Date(); // 現在の日時
console.log(d); // 2016-08-08T08:45:46.332Z
const ts = d.valueOf(); // UTCの1970年1月1日午前0時からのミリ秒数
console.log(ts); // 1470645946332
