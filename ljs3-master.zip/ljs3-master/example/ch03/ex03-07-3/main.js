let currentTemp = 19.5;
const message = `現在の温度は${currentTemp}℃です。`;
console.log(message); // 現在の温度は19.5℃です。
