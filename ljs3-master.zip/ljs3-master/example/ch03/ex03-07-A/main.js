const result1 = 3 + '30';  // 3は文字列に変換され、結果は文字列の'330'になる
console.log(result1); // 330
const result2 = 3 * '30';  // '30'は数値に変換され、結果は数値の90になる
console.log(result2); // 90
