const d = new Date();
console.log(d.toString()); // Mon Aug 08 2016 18:02:50 GMT+0900 (JST)

const arr = [1, true, "hello"];
console.log(arr.toString()); // 1,true,hello
