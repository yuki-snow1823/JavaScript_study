const s = "hello";
s.rating = 3; // エラーなし...成功？
console.log(s.rating); // undefined
