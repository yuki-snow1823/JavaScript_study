const obj = {};
obj.color = "黄色";
console.log(obj.color); // 黄色
