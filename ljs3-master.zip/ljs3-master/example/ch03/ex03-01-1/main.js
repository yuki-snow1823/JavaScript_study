let currentTempC = 16;  // 現在の温度。単位は摂氏
console.log(currentTempC); // 16  （←出力結果）
currentTempC = 22.5;
console.log(currentTempC); // 22.5
