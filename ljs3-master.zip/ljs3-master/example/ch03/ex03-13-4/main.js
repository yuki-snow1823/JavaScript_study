const a = ['a', 'b', 'c'];
console.log(a.length); // 3
a[1.3] = "one point three";
console.log(a[1.3]);
a[-2] = "minus two";
console.log(a[-2]);
console.log(a);
console.log(a.length); // 3