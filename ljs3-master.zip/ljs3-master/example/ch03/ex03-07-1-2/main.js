let x = "De Morgan’s law: \u2310(P \u22c0 Q) \u21D4 (\u2310P) \u22c1 (\u2310Q)";
console.log(x); // De Morgan’s law: ⌐(P ⋀ Q) ⇔ (⌐P) ⋁ (⌐Q)
x = "\xc9p\xe9e is fun, but foil is more fun.";
console.log(x); // Épée is fun, but foil is more fun.

