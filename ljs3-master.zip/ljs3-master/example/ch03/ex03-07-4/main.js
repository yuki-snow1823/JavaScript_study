const multiline = "1行目\
2行目";
console.log(multiline); // 1行目2行目
