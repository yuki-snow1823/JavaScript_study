const s = "hello";
const s2 = s.toUpperCase(); // 大文字に変換した文字列をs2に代入
console.log(s2); // HELLO
