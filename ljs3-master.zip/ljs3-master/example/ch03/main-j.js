let 現在の気温_摂氏 = 22; 
console.log("現在の気温（letの後）=" + 現在の気温_摂氏);	
現在の気温_摂氏 = 22.5; 
console.log("現在の気温（代入の後）=" + 現在の気温_摂氏);

let 目標温度, 部屋1 = "会議室A", 部屋2 = "ロビー";

const C部屋の温度 = 21.5, C最高温度 = 30; // const変数にはCを付けることに





// シンボル
const SYM赤 = Symbol();
const SYMオレンジ = Symbol("夕日の色！");
const SYM夕日の色 = Symbol("夕日の色！");
const シンボルの比較結果 =  SYM赤 === SYMオレンジ  // false: シンボルはすべてユニーク
const シンボルの比較結果2 =  SYMオレンジ === SYM夕日の色
const シンボルの比較結果3 =  SYMオレンジ == SYM夕日の色


