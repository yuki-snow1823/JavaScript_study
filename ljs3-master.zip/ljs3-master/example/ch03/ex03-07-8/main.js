const multiline = "1行目\n" +
	"2行目\n" +
	"3行目";
console.log(multiline);

/* 実行結果
1行目
2行目
3行目
*/
