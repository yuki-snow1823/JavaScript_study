const x = 0.1+0.2;
console.log(x); // 0.30000000000000004
