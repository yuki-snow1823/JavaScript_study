const n = 0;
const b0 = !n;
const b1 = !!n;
const b2 = Boolean(n);
console.log(n); // 0
console.log(b0); // true
console.log(b1); // false
console.log(b2); // false

const m = 1;
const c0 = !m;
const c1 = !!m;
const c2 = Boolean(m);
console.log(m); // 1
console.log(c0); // fasle
console.log(c1); // true
console.log(c2); // true
