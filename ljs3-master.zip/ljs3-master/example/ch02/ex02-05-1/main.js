$(document).ready(function() {
   'use strict';
   console.log('jQueryはすでにロードされているはず。');
   console.log('main.jsをロードした。');
});
