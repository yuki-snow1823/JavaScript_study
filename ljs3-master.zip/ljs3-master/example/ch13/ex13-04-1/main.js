const v = function() { };
const a = [1, 2, 3];

console.log(typeof(v)); // function
console.log(typeof(a)); // object
console.log(v instanceof Object); // true
