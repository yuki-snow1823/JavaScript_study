const book = [
  "ある所に初老の夫婦が住んでたとさ。",
  "夫は山へ妻は川へ行ったとさ。",
  "妻が川で洗濯をしていると、",
  "上流から桃が流れてきたとさ。",
  "ドンブラコッコ、スッコッコ、",
  "ドンブラコッコ、スッコッコ。",
];

// #@@range_begin(list1)
book.next();

/* 実行結果 （エラーが起こる）
TypeError: book.next is not a function
*/
// #@@range_end(list1)
