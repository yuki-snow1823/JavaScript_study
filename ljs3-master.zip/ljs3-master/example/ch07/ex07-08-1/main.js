let var1;
let var2 = undefined;
console.log(var1); // undefined
console.log(var2); // undefined
console.log(undef); // ReferenceError: undef is not defined   （エラー）
