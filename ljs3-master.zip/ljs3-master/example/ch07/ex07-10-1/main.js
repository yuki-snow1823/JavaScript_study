if(typeof x === "undefined") {
  console.log("xは存在していない、あるいはundefined");
} else {
  // xを参照しても大丈夫...
}
var x;
