let f = function() {
  console.log('関数fが呼び出された');
}
console.log(f); // [Function: f]
f(); // 関数fが呼び出された
