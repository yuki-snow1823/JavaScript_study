var x;
console.log(x); // undefined
x = 3;
console.log(x); // 3
