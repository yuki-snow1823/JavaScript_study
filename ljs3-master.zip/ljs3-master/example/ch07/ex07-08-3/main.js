console.log(x); // undefined
var x = 3;
console.log(x); // 3
