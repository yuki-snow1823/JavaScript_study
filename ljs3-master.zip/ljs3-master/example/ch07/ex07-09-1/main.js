f(); // 関数fが呼び出された
function f() {
  console.log('関数fが呼び出された');
}
