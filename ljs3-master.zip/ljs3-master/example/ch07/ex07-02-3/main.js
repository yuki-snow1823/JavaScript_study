const x = 3;
function f() {
  console.log(x); // 3  （これは動く）
  console.log(y); // 3  （これも動く）
}

const y = 3;
f();
