function f(x) {
  return x + 3;
}
console.log(f(5)); // 8
console.log(x); // エラー    ReferenceError: x is not defined（xは定義されていない）
