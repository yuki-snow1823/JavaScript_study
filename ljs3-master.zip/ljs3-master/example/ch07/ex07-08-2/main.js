x; // ReferenceError: x is not defined   （エラー）
let x = 3;   /* （上でエラーになってしまったここには到達しない） */
